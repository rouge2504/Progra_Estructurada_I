using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MedabotManager : MonoBehaviour
{
    public Medabot medabotTest;

    public void Start()
    {
        print(medabotTest.life);
    }
}
